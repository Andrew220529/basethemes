<?php
/*
Template Name: Java Script tag
*/
?>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
<meta name="format-detection" content="telephone=no">
<script src="https://code.jquery.com/jquery-1.10.1.min.js"></script>
<script src="https://kit.fontawesome.com/22a0b4b7b8.js" crossorigin="anonymous"></script>
