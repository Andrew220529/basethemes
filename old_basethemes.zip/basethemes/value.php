<?php
/*
Template Name: value tag
*/
?>