<?php
/*
Template Name: contactlink tag
*/
?>