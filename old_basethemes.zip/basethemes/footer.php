<?php
/*
Template Name: footer tag
*/
?>